<?php
/**
 * AKAH Mobile child theme setup.
 *
 * @package AkahMobile
 */

defined( 'ABSPATH' ) || exit;

require_once get_stylesheet_directory() . '/inc/storefront.php';

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'woocommerce' );
}, 20 );

add_filter( 'template_include', function ( $template ) {
	if ( ! is_feed() && ! is_embed() && ! is_trackback() ) {
		return get_stylesheet_directory() . '/storefront.php';
	}
	return $template;
}, 99 );

// The React storefront supplies the layout and assets for the public shell.
add_filter( 'astra_enqueue_theme_assets', '__return_false' );

add_action( 'wp_enqueue_scripts', function () {
	$assets = get_stylesheet_directory_uri() . '/assets/';
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'akah-storefront', $assets . 'app/storefront.css', array(), $version );
	wp_enqueue_style( 'akah-woocommerce', $assets . 'woocommerce.css', array( 'akah-storefront' ), $version );
	wp_enqueue_script( 'akah-storefront', $assets . 'app/storefront.js', array(), $version, true );

	if ( class_exists( 'WooCommerce' ) ) {
		wp_enqueue_script( 'wc-cart-fragments' );
	}
}, 100 );

add_action( 'wp_head', function () {
	if ( ! has_site_icon() ) {
		printf( '<link rel="icon" href="%s" type="image/png">' . "\n", esc_url( get_stylesheet_directory_uri() . '/assets/images/favicon.png' ) );
	}
} );

add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$fragments['#akah-cart-count'] = akah_cart_count_markup();
	return $fragments;
} );

add_action( 'woocommerce_after_add_to_cart_button', function () {
	global $product;
	if ( ! is_product() || ! $product || ! $product->is_type( array( 'simple', 'variable' ) ) ) {
		return;
	}
	if ( $product->is_type( 'simple' ) ) {
		printf( '<input type="hidden" name="add-to-cart" value="%d">', $product->get_id() );
	}
	printf(
		'<button type="submit" class="button akah-buy-now" name="akah_buy_now" value="1"%s>Mua ngay</button>',
		$product->is_type( 'variable' ) ? ' disabled' : ''
	);
} );

add_filter( 'woocommerce_add_to_cart_redirect', function ( $url ) {
	if ( isset( $_POST['akah_buy_now'] ) ) {
		return wc_get_checkout_url();
	}
	if ( isset( $_POST['akah_quick_add'] ) ) {
		return $url ?: wp_validate_redirect( wp_get_referer(), wc_get_cart_url() );
	}
	return $url;
} );

add_filter( 'woocommerce_account_menu_items', function ( $items ) {
	$labels = array(
		'dashboard'       => 'Tổng quan',
		'orders'          => 'Đơn hàng của tôi',
		'downloads'       => 'Tệp tải xuống',
		'edit-address'    => 'Sổ địa chỉ',
		'edit-account'    => 'Thông tin cá nhân',
		'payment-methods' => 'Phương thức thanh toán',
		'customer-logout' => 'Đăng xuất',
	);
	return array_replace( $items, array_intersect_key( $labels, $items ) );
} );

add_filter( 'gettext_woocommerce', function ( $translated, $source ) {
	if ( is_user_logged_in() || ! did_action( 'wp' ) || ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
		return $translated;
	}
	$labels = array(
		'Username or email address' => 'Tên đăng nhập hoặc email',
		'Username'                  => 'Tên đăng nhập',
		'Email address'             => 'Địa chỉ email',
		'Password'                  => 'Mật khẩu',
		'Log in'                    => 'Đăng nhập',
		'Register'                  => 'Tạo tài khoản',
		'Remember me'               => 'Ghi nhớ đăng nhập',
		'Lost your password?'       => 'Quên mật khẩu?',
		'A link to set a new password will be sent to your email address.' => 'WooCommerce sẽ gửi liên kết đặt mật khẩu tới email của bạn.',
	);
	return $labels[ $source ] ?? $translated;
}, 10, 2 );
